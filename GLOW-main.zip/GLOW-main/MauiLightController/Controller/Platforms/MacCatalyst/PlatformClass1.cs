﻿namespace Controller
{
    // All the code in this file is only included on Mac Catalyst.
    public class PlatformClass1
    {
    }
}